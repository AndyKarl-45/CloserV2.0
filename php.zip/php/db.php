<?php

try {
    // $db = new PDO('mysql:host=localhost;dbname=apfood_syges_btp;charset=utf8', 'apfood_syges_btp_root', 'jk5N{^-&znT{');
    $db = new PDO('mysql:host=localhost;dbname=closer_onigc_syges;charset=utf8', 'closer_onigc_syges_root', 'j,jjkp{.RE${');
} catch (PDOException $e) {
    die('Erreur: ' . $e->getMessage());
}
?>