 <?php
    include("first.php");
    include('php/navbar_links.php');
    include("php/db.php")
?>

<?php

if($_POST)
{               


        
        $nom_en = $_POST['nom_en'];
        $type_en = $_POST['type_en'];
        $pays_en = 'N/A';
        $ville_en = 'N/A';
        $tel_en = $_POST['tel_en'];
        $email_en = $_POST['email_en'];
        $pers_en = $_POST['pers_en'];
        $contact_en = $_POST['contact_en'];
       

                          

//--------------------------------- insertion un fournisseur -----------------------------------------//
                   

         $query = " INSERT INTO entreprise (nom_en,type_en,pays_en,ville_en,tel_en,email_en,pers_en,contact_en) 
                     VALUES (:nom_en,:type_en,:pays_en,:ville_en,:tel_en,:email_en,:pers_en,:contact_en)";

                 $sql = $db->prepare($query);

     // Bind parameters to statement
            $sql->bindParam(':nom_en', $nom_en);
            $sql->bindParam(':type_en', $type_en);
            $sql->bindParam(':pays_en', $pays_en);
            $sql->bindParam(':ville_en', $ville_en);
            $sql->bindParam(':tel_en', $tel_en);
            $sql->bindParam(':email_en', $email_en);
            $sql->bindParam(':pers_en', $pers_en);
            $sql->bindParam(':contact_en', $contact_en);
            $sql->execute();



                                    if($sql)
                                    {
                                        ?>
                                        <script>
                                            // alert('fournisseur a été bien enregistrée.');
                                                window.location.href='<?=$entreprise['option2_link']?>?witness=1';
                                        </script>
                                        <?php
                                    }

                                    else
                                    {       
                                      ?>
                                        <script>
                                            alert('Error.');
                                            window.location.href='<?=$entreprise['option2_link']?>?witness=-1';
                                        </script>
                                        <?php
                                       
                                    }


}
?>
