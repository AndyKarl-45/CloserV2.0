 <?php
    include("first.php");
    include('php/navbar_links.php');
    include("php/db.php")
?>

<?php

if($_POST)
{               

         $year = (new DateTime())->format("Y");
         $month = (new DateTime())->format("m");
         $day = (new DateTime())->format("d");

         $id_perso= $_POST['id_personnel'];
        $id_caisse= $_POST['id_caisse'];
        $date_dem_part=$_POST['date_dem_part'];
      
        $sql="SELECT YEAR('$date_dem_part') as total  ";
                                                                $stmt = $db->prepare($sql);
                                                                $stmt->execute();

                                                                $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                                                foreach($tables as $table)
                                                                    {
                                                                        $annee=$table['total'];
                                                                    }
       
        
        
        
        $id_ing=$_POST['id_ing'];
         // $droit=$_POST['droit'];
         $droit='Payer';

         $sql="SELECT count(id_dem_part) as total FROM demande_particulier where id_caisse='$id_caisse' and id_ing='$id_ing' ";
                            $stmt = $db->prepare($sql);
                            $stmt->execute();

                             $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach($tables as $table)
                                        {
                                          $count=$table['total'];
                                            
                                           
                                        }
if($count==0){
          
        $ref_dem_part='ATTP00000'.$id_ing.'/ONIGC/'.$annee;
       
        
      
        
                                    $sql = "INSERT INTO demande_particulier (id_caisse,ref_dem_part,id_ing,droit,date_dem_part,id_perso)
                                  VALUES (?,?,?,?,?,?)";
                                $req = $db->prepare($sql);
                                $req->execute(array($id_caisse,$ref_dem_part,$id_ing,$droit,$date_dem_part,$id_perso));

                                    if($sql)
                                    {
                                        ?>
                                        <script>
                                           // alert('Profession a été bien enregistrée.');
                                            window.location.href='<?=$demande_particulier['option2_link']?>?witness=1';
                                        </script>
                                        <?php
                                    }

                                    else
                                    {       
                                      ?>
                                        <script>
                                           // alert('Error.');
                                            window.location.href='<?=$demande_particulier['option2_link']?>?witness=-1';
                                        </script>
                                        <?php
                                       
                                    }


}else{

                                     ?>
                                        <script>
                                            alert('Existe Déjà !!! ');
                                             window.location.href='<?=$demande_particulier['option2_link']?>?witness=-1';
                                        </script>
                                        <?php
}

}
?>
