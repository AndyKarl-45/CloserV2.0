<?php

include('first.php');
include("php/db.php");
include('php/main_side_navbar.php');

?>

    <!--Content-->

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4"> <i class=" fas fa-user-graduate" style="color: silver"></i> Liste des membres</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">
                        Hello M/Mme XXX, il est <?= date("G:i"); ?> en ce jour du <?= dateToFrench("now", "l j F Y"); ?>
                        .

                    </li>
                </ol>
                <div class="row">
                    <div class="col-xl-12">


                        <b>
                            <!-- Nav pills -->
                            <ul class="nav nav-pills" style="float: right;">
                                <li class="nav-item">
                                    <a class="btn btn-primary" href="<?=$ingenieur['option1_link']?>">
                                        <i class="fas fa-plus-circle"></i>
                                        Nouveau membre 
                                    </a>
                                </li>
                            </ul>
                        </b>


                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <hr/>
                    </div>
                </div>
                <!--                Main Body              -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-border table-striped custom-table mb-0" id="dataTable">
                                <thead>
                                <tr align="center" style="background-color: #dde9dd">
                                     
                                   <th>Matricule</th>
                                     <th>Année</th>
                                    <th>Nom</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th ><i class="fas fa-bars"></i></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php

                                $query = "SELECT * from mytable where statut='N/A'  order by nom_ing asc";
                                $q = $db->query($query);
                                while ($row = $q->fetch()) {
                                    $id_ingenieur = $row['id_ingenieur'];
                                    $matricule = $row['matricule'];
                                    $nom_ing = $row['nom_ing'];
                                    $prenom_ing = $row['prenom_ing'];
                                    $num_ordre = $row['num_ordre'];
                                    $tel_ing = $row['tel_ing'];
                                    $email_ing = $row['email_ing'];
                                    $date_inscription = $row['date_inscription'];
                                    $annee = $row['annee'];

                                    ?>
                                    <tr >
                                       <input name="id" type="hidden"
                                                                       value="<?php echo $id_ingenieur ?>"/>
                                                                <td align="center" style="width:15%"><a
                                                                            href="details_ingenieur.php?id=<?php echo $id_ingenieur; ?>"
                                                                            title="<?= $matricule; ?>"
                                                                            style="color: black"><?= $matricule ?> </a></td>
                                                                <td align="center" style="width:15%"><a
                                                                            href="details_ingenieur.php?id=<?php echo $id_ingenieur; ?>"
                                                                            title="<?= $annee; ?>"
                                                                            style="color: black"><?= $annee; ?></a></td>
                                                                <td style="width:25%"><img width="28" height="28" src="assetss/img/user.jpg"
                                                 class="rounded-circle m-r-5" alt=""><a
                                                                            href="details_ingenieur.php?id=<?php echo $id_ingenieur; ?>"
                                                                            title="<?= $nom_ing; ?>"
                                                                            style="color: black"><?= $nom_ing . ' ' . $prenom_ing; ?></a>
                                                                </td>
                                                                <td align="center"style="width:18%"><a
                                                                            href="details_ingenieur.php?id=<?php echo $id_ingenieur; ?>"
                                                                            title="<?= $tel_ing; ?>"
                                                                            style="color: black"><?= $tel_ing ?> </a></td>
                                                                <td align="center" style="width:22%"><a
                                                                            href="details_ingenieur.php?id=<?php echo $id_ingenieur; ?>"
                                                                            title="<?= $email_ing; ?>"
                                                                            style="color: black"><?= $email_ing; ?></a></td>
                                                                <td align="center"style="width:10%">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown"
                                                   aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="modifier_ingenieur.php?id=<?=$id_ingenieur?>"><i
                                                                class="fas fa-pen"></i> Edit</a>
                                                    <a class="dropdown-item" href="#" data-toggle="modal"
                                                       data-target="#delete_patient"><i class="fas fa-trash"></i>
                                                        Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--                End Body              -->

                <div class="row">
                    <div class="col-md-12">
                        <hr/>
                    </div>
                </div>

            </div>
        </main>
    </div>
<?php
if (isset($_GET['witness'])) {
    $witness = $_GET['witness'];

    switch ($witness) {
        case '1';
            ?>
            <script>
                Swal.fire(
                    'Succès',
                    'Opération effectuée avec succès !',
                    'success'
                )
            </script>
            <?php
            break;
        case '-1';
            ?>
            <script>
                Swal.fire({
                    icon: 'Erreur',
                    title: 'Oops...',
                    text: 'Une erreur s\'est produite !',
                    footer: 'Reéssayez encore'
                })
            </script>
            <?php
            break;

    }
}
?>


    <!--//Footer-->
<?php
include('foot.php');
?>