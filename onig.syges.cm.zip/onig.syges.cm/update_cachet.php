<?php
include("first.php");
include('php/navbar_links.php');
include("php/db.php")
?>

<?php

if ($_POST) {


    /*--------------------------------- ETAT INFOS RH -------------------------------------*/
    $id = $_POST['id_cachet'];
    $id_ing = $_POST['id_ing'];
    $statut = $_POST['id_statut'];
    $tel = $_POST['tel'];
    $annee = $_POST['annee'];

            $sql="SELECT *  FROM mytable where id_ingenieur='$id_ing' ";
                            $stmt = $db->prepare($sql);
                            $stmt->execute();

                             $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach($tables as $table)
                                        {
                                            $matricule=$table['matricule'];
                                        }
     
             

        /*--------------------------------- SAVE DATA CIVIL STATE ---------------------------*/

        $query1 = "UPDATE demande_cachet SET id_ingenieur=:id_ing, matricule=:matricule, statut=:statut, tel=:tel,  annee=:annee where id_cachet = '$id' ";
  
        $sql1 = $db->prepare($query1);

             // Bind parameters to statement
            $sql1->bindParam(':id_ing', $id_ing);
            $sql1->bindParam(':matricule', $matricule);
            $sql1->bindParam(':statut', $statut);
            $sql1->bindParam(':tel', $tel);
            $sql1->bindParam(':annee', $annee);
            $sql1->execute();



                                    if($sql1)
                                    {
                                        ?>
                                        <script>
                                           // alert('Personnel a été bien modifié.');
                                                  window.location.href='liste_cachet.php?&witness=1';
                                        </script>
                                        <?php
                                    }

                                    else
                                    {       
                                      ?>
                                        <script>
                                            alert('Demande n\'a pas été modifié.');
                                            window.location.href='modifier_cachet.php?id=<?=$id?>';
                                        </script>
                                        <?php
                                       
                                    }


   

}
?>
