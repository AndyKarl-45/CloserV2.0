 <?php
    include("first.php");
    include('php/navbar_links.php');
    include("php/db.php")
?>

<?php

if($_POST)
{               

         // $year = (new DateTime())->format("Y");
         // $month = (new DateTime())->format("m");
         // $day = (new DateTime())->format("d");

       $id_ing = $_POST['id_ing'];
       $tel= $_POST['tel'];
       $id_statut=$_POST['id_statut'];
       $date_cachet=date('Y-m-d');
       $annee=date('Y');



              

         $sql="SELECT matricule, count(id_ingenieur) as total FROM  mytable where id_ingenieur='$id_ing'";
                            $stmt = $db->prepare($sql);
                            $stmt->execute();

                             $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach($tables as $table)
                                        {
                                        echo  $matricule=$table['matricule'];
                                        echo  $count=$table['total'];
                                           
                                       
if($count!=0){


        
      
        
                                    $sql = "INSERT INTO demande_cachet (id_ingenieur,matricule,statut,tel,date_cachet,annee)
                                  VALUES (?,?,?,?,?,?)";
                                $req = $db->prepare($sql);
                                $req->execute(array($id_ing,$matricule,$id_statut,$tel,$date_cachet,$annee));

                                    if($req)
                                    {
                                        ?>
                                        <script>
                                        //alert('Demandea été bien enregistrée.');
                                              window.location.href='<?=$demande_cachet['option2_link']?>?witness=1';
                                        </script>
                                        <?php
                                    }

                                    else
                                    {       
                                      ?>
                                        <script>
                                            alert('Error.');
                                             window.location.href='<?=$demande_cachet['option2_link']?>?witness=-1';
                                        </script>
                                        <?php
                                       
                                    }



}else{

         ?>
                                        <script>
                                            alert('Ingénieur n\'existe pas !!! ');
                                              window.location.href='<?=$demande_cachet['option2_link']?>?witness=-1';
                                        </script>
                                        <?php
                                    }

     }



}
?>
