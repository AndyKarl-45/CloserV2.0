<?php
include ("php/dbconnect.php");


if (isset($_REQUEST['id'])) {
    $id_ingenieur = $_REQUEST['id'];
    $nom = $_REQUEST['pj'];
    

    $query = "DELETE FROM $nom WHERE id_entite='$id_ingenieur'";
    $sql = $conn->query($query);


    if ($sql)
    {
        echo "<script>
                 window.location.href='details_postulant.php?id=$id_ingenieur&witness=1';
            </script>";
    }
    else
    {

        echo "<script>
                window.location.href='details_postulant.php?id=$id_ingenieur&witness=1';
            </script>";
    }
}
