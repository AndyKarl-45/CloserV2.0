<?php

if (!isset($_SESSION['rainbo_name']))
    echo '<script type="text/javascript">window.location="connexion.php"; </script>';

?>